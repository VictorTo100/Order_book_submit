DROP TABLE IF EXISTS order_book;
 
CREATE TABLE order_book (
id VARCHAR(250) DEFAULT NULL PRIMARY KEY,
  sym VARCHAR(250) NOT NULL ,
  timestamp TIMESTAMP NOT NULL,
  price double NOT NULL,
  side  VARCHAR(250) NOT NULL,
  lots  INTEGER NOT NULL,
  action VARCHAR(250) DEFAULT NULL
);

INSERT INTO order_book (id, sym, timestamp, price, side, lots, action) VALUES ('1f07623c-332c-4cb7-83bf-ebef38684a63','GBP/USD', '2020-01-01 22:01:30.485000', 1.32737, 'Ask', 9, 'modify');
