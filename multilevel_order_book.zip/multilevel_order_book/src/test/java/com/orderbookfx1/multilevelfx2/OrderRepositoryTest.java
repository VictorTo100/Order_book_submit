package com.orderbookfx1.multilevelfx2;


import com.orderbookfx1.multilevelfx2.models.OrderBook;
import com.orderbookfx1.multilevelfx2.repository.OrderRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class OrderRepositoryTest {
    /**
     * Test to check if the data is been pulled correctly
     * 1. Do Sanity checks on the data types returned from database
     */

    @Autowired
    private OrderRepository orderRepository;

    // Check if the data is read as expected
    @Test
    public void testFindAll(){
        List<OrderBook> orders = orderRepository.findAll();
        assertEquals(1, orders.size());

    }

    // Check if the data is read as expected
    @Test
    public void checkDataType(){
        List<OrderBook> orders = orderRepository.findAll();
        String id = orders.get(0).getId();
        String sym = orders.get(0).getSym();
        String side = orders.get(0).getSide();
        Timestamp timestamp = orders.get(0).getTimestamp();
        Double price = orders.get(0).getPrice();
        int lots = orders.get(0).getLots();
        String action = orders.get(0).getAction();
        Double expectedPrice = 1.32737;
        assertEquals(id, "1f07623c-332c-4cb7-83bf-ebef38684a63");
        assertEquals(sym, "GBP/USD");
        assertEquals(side, "Ask");
        assertEquals(timestamp, Timestamp.valueOf("2020-01-01 22:01:30.485"));
        assertEquals(lots, 9);
        assertEquals(action, "modify");
        assertEquals(price, expectedPrice);

    }










}
