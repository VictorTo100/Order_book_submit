package com.orderbookfx1.multilevelfx2;

import com.orderbookfx1.multilevelfx2.exceptions.Error;
import com.orderbookfx1.multilevelfx2.models.*;
import com.orderbookfx1.multilevelfx2.repository.OrderRepository;
import com.orderbookfx1.multilevelfx2.services.DataManipulationService;
import com.orderbookfx1.multilevelfx2.resources.Utility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.util.*;

import static org.mockito.Mockito.*;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Utility.class, UtilityResponse.class, DataManipulationService.class,
        TopOfTheBookResponse.class, OrderBook.class, OrderBookResponse.class, TopNOfTheBookResponse.class})
public class DataManipulationServiceTest {

    @MockBean
    private Utility utilities;
    @Autowired
    DataManipulationService dataManipulationService;
    @Autowired
    private OrderBookResponse orderBookResponse;
    @Autowired
    private TopNOfTheBookResponse topNOfTheBookResponse;
    @Autowired
    private TopOfTheBookResponse topOfTheBookResponse;
    @MockBean
    private UtilityResponse utilityResponse;
    // Mock the repository
    @MockBean
    private OrderRepository orderRepository;

    @Before
    public void setup(){
        MockitoAnnotations.initMocks(this);
    }


    /**
     * Testing for the all data service
     * Replicating the data when order repository find all function is called
     */

    @Test
    public void testAllOrders(){
        ArrayList<OrderBook> orderArrayList =
                new ArrayList<>(Arrays.asList(new OrderBook("order_1","GBPUSD","Bid",11.0, 6,  Timestamp.valueOf("2020-01-01 22:01:30.485"), "add"),
                new OrderBook("order_2","GBPUSD", "Ask", 12.0, 5, Timestamp.valueOf("2020-01-01 22:01:30.485"), "add" )));
        when(orderRepository.findAll()).thenReturn(orderArrayList);

        ArrayList<OrderBook> expectedOutput =
                new ArrayList<>(Arrays.asList(new OrderBook("order_1","GBPUSD","Bid",11.0, 6,  Timestamp.valueOf("2020-01-01 22:01:30.485"), "add"),
                        new OrderBook("order_2","GBPUSD", "Ask", 12.0, 5, Timestamp.valueOf("2020-01-01 22:01:30.485"), "add" )));
        ArrayList<OrderBook> actual =  dataManipulationService.getAllData().getOrderBooks();
        assertEquals(expectedOutput, actual);
    }

    @Test
    public void testAllOrderNoData(){

        when(orderRepository.findAll()).thenReturn(new ArrayList<>());
        Error expectedError = new Error(new Date(), "No data found", "ML101");
        OrderBookResponse actual =  dataManipulationService.getAllData();
        ArrayList<Error> actualError = actual.getErrors();
        assertEquals(expectedError.getCode(), actual.getErrors().get(0).getCode());
    }

    @Test
    public void testingTopOfTheBook() throws Exception {
        HashMap<String, Object> collectData = getTestDataTopOfTheBook();
        ArrayList<OrderBook> orderArrayList = (ArrayList<OrderBook>) collectData.get("orderArrayList");
        ArrayList<OrderBook> filterBid = (ArrayList<OrderBook>) collectData.get("filterBid");
        ArrayList<OrderBook> filterAsk = (ArrayList<OrderBook>) collectData.get("filterAsk");
        ArrayList<OrderBook> orderArrayListAction = (ArrayList<OrderBook>) collectData.get("orderArrayListAction");
        HashMap<String, Object> innerMap_1 = (HashMap<String, Object>) collectData.get("inner_map_1");
        HashMap<String, Object> innerMap_2 = (HashMap<String, Object>) collectData.get("inner_map_2");

        Map<Double, Long> bidPriceLotSize = new HashMap<Double, Long>();
        bidPriceLotSize.put(11D, 11L);

        Map<Double, Long> askPriceLotSize = new HashMap<Double, Long>();
        askPriceLotSize.put(12D, 10L);

        Map<Double, Long> countBidOrders = new HashMap<Double, Long>();
        countBidOrders.put(11D, 2L);

        Map<Double, Long> countAskOrders = new HashMap<Double, Long>();
        countAskOrders.put(12D, 2L);

        Error getAllDataError = new Error(new Date(), "No data found", "ML102");
        ArrayList<Error> listofErrors = new ArrayList<Error>();
        listofErrors.add(getAllDataError);
        UtilityResponse bidUtilFilter = new UtilityResponse(null, null, filterBid, null);
        UtilityResponse askUtilFilter = new UtilityResponse(null, null, filterAsk, null);
        UtilityResponse bidLotSum = new UtilityResponse(bidPriceLotSize, null, null, null);
        UtilityResponse askLotSum = new UtilityResponse(askPriceLotSize, null, null, null);
        UtilityResponse bidCnt = new UtilityResponse(null, countBidOrders, null, null);
        UtilityResponse askCnt = new UtilityResponse(null, countAskOrders, null, null);
        UtilityResponse actionFilter = new UtilityResponse(null, null, orderArrayListAction, null);

        when(dataManipulationService.getAllData().getOrderBooks()).thenReturn(actionFilter.getArrayListOrderBook());
        when(utilities.filterSide(orderArrayList, "Bid")).thenReturn(bidUtilFilter);
        when(utilities.filterSide(orderArrayList, "Ask")).thenReturn(askUtilFilter);
        when(utilities.groupByPriceLotSum(filterAsk)).thenReturn(bidLotSum);
        when(utilities.groupByPriceLotSum(filterBid)).thenReturn(askLotSum);
        when(utilities.groupByPriceCountOrders(filterAsk)).thenReturn(bidCnt);
        when(utilities.groupByPriceCountOrders(filterBid)).thenReturn(askCnt);

        HashMap<String, HashMap<String, Object>> topOfTheBook = new HashMap<String, HashMap<String, Object>>();

        topOfTheBook.put("Ask", innerMap_1);
        topOfTheBook.put("Bid", innerMap_2);

        TopOfTheBookResponse expectedOutput = new TopOfTheBookResponse(null, topOfTheBook);
        HashMap<String, HashMap<String, Object>> outputMap = dataManipulationService.getTopOfTheBookOrders().getTopOfTheBook();
        Set<String> outMapKeys = outputMap.keySet();
        Set<String> expectedMapKeys = expectedOutput.getTopOfTheBook().keySet();
        assertEquals(expectedMapKeys, outMapKeys);
        for (String key: outputMap.keySet()){
            for(String key_in: outputMap.get(key).keySet())
                assertEquals(expectedOutput.getTopOfTheBook().get(key).get(key_in), (outputMap.get(key).get(key_in)));
        }
    }


    /**
     * Data preparation method for testing top of the order book data
     */

    private HashMap<String, Object> getTestDataTopOfTheBook(){
        HashMap<String, Object> collectData = new HashMap<String, Object>();
        ArrayList<OrderBook> orderArrayList =
                new ArrayList<>(Arrays.asList(new OrderBook("1f07623c-332c-4cb7-83bf-ebef38684a63","GBP/USD","Ask", 1.32737, 9, Timestamp.valueOf("2020-01-01 22:01:30.485000"), "modify"),
                        new OrderBook("20e13c0f-0f45-434e-9a02-539c4ed6e639","GBP/USD", "Ask", 1.32687, 6, Timestamp.valueOf("2020-01-01 22:02:31.163000"), "add"),
                        new OrderBook("fc311112-93d7-486b-b4fa-e096c3224520","GBP/USD", "Ask", 1.32737, 6, Timestamp.valueOf("2020-01-01 22:02:37.558000"), "modify"),
                        new OrderBook("d560c699-1cef-4788-83eb-2efb4ee8fddf","GBP/USD", "Ask", 1.32569, 1, Timestamp.valueOf("2020-01-01 22:02:45.147000"), "add"),
                        new OrderBook("f9f398e3-19cb-4068-86cb-02af9fb87724","GBP/USD", "Ask", 1.32569, 6, Timestamp.valueOf("2020-01-01 22:02:45.571000"), "add"),
                        new OrderBook("4f928660-e830-4ab4-9559-94da8b5d2071","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.571000"), "add"),
                        new OrderBook("528d441e-1680-494f-85c2-b7d2920c3ef4","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.677000"), "modify"),
                        new OrderBook("e144661b-85fc-4f38-985d-91e903ab5cba","GBP/USD", "Bid", 1.32568, 9, Timestamp.valueOf("2020-01-01 22:02:47.361000"), "delete"),
                        new OrderBook("6adaf204-c499-4bda-9146-a053a27c8c77","GBP/USD", "Bid", 1.32567, 3, Timestamp.valueOf("2020-01-01 22:02:49.927000"), "add"),
                        new OrderBook("53995a6e-70a6-4b32-863a-40c340443fd7","GBP/USD", "Bid", 1.32567, 7, Timestamp.valueOf("2020-01-01 22:02:50.136000"), "add")));
        ArrayList<OrderBook> filterAsk = new ArrayList<>(Arrays.asList(new OrderBook("1f07623c-332c-4cb7-83bf-ebef38684a63","GBP/USD","Ask", 1.32737, 9, Timestamp.valueOf("2020-01-01 22:01:30.485000"), "modify"),
                new OrderBook("20e13c0f-0f45-434e-9a02-539c4ed6e639","GBP/USD", "Ask", 1.32687, 6, Timestamp.valueOf("2020-01-01 22:02:31.163000"), "add"),
                new OrderBook("fc311112-93d7-486b-b4fa-e096c3224520","GBP/USD", "Ask", 1.32737, 6, Timestamp.valueOf("2020-01-01 22:02:37.558000"), "modify"),
                new OrderBook("d560c699-1cef-4788-83eb-2efb4ee8fddf","GBP/USD", "Ask", 1.32569, 1, Timestamp.valueOf("2020-01-01 22:02:45.147000"), "add"),
                new OrderBook("f9f398e3-19cb-4068-86cb-02af9fb87724","GBP/USD", "Ask", 1.32569, 6, Timestamp.valueOf("2020-01-01 22:02:45.571000"), "add")
                ));
        ArrayList<OrderBook> filterBid =
                new ArrayList<>(Arrays.asList(new OrderBook("4f928660-e830-4ab4-9559-94da8b5d2071","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.571000"), "add"),
                        new OrderBook("528d441e-1680-494f-85c2-b7d2920c3ef4","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.677000"), "modify"),
                        new OrderBook("e144661b-85fc-4f38-985d-91e903ab5cba","GBP/USD", "Bid", 1.32568, 9, Timestamp.valueOf("2020-01-01 22:02:47.361000"), "delete"),
                        new OrderBook("6adaf204-c499-4bda-9146-a053a27c8c77","GBP/USD", "Bid", 1.32567, 3, Timestamp.valueOf("2020-01-01 22:02:49.927000"), "add"),
                        new OrderBook("53995a6e-70a6-4b32-863a-40c340443fd7","GBP/USD", "Bid", 1.32567, 7, Timestamp.valueOf("2020-01-01 22:02:50.136000"), "add")));
        ArrayList<OrderBook> orderArrayListAction =
                new ArrayList<>(Arrays.asList(new OrderBook("1f07623c-332c-4cb7-83bf-ebef38684a63","GBP/USD","Ask", 1.32737, 9, Timestamp.valueOf("2020-01-01 22:01:30.485000"), "modify"),
                        new OrderBook("20e13c0f-0f45-434e-9a02-539c4ed6e639","GBP/USD", "Ask", 1.32687, 6, Timestamp.valueOf("2020-01-01 22:02:31.163000"), "add"),
                        new OrderBook("fc311112-93d7-486b-b4fa-e096c3224520","GBP/USD", "Ask", 1.32737, 6, Timestamp.valueOf("2020-01-01 22:02:37.558000"), "modify"),
                        new OrderBook("d560c699-1cef-4788-83eb-2efb4ee8fddf","GBP/USD", "Ask", 1.32569, 1, Timestamp.valueOf("2020-01-01 22:02:45.147000"), "add"),
                        new OrderBook("f9f398e3-19cb-4068-86cb-02af9fb87724","GBP/USD", "Ask", 1.32569, 6, Timestamp.valueOf("2020-01-01 22:02:45.571000"), "add"),
                        new OrderBook("4f928660-e830-4ab4-9559-94da8b5d2071","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.571000"), "add"),
                        new OrderBook("528d441e-1680-494f-85c2-b7d2920c3ef4","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.677000"), "modify"),
                        new OrderBook("6adaf204-c499-4bda-9146-a053a27c8c77","GBP/USD", "Bid", 1.32567, 3, Timestamp.valueOf("2020-01-01 22:02:49.927000"), "add"),
                        new OrderBook("53995a6e-70a6-4b32-863a-40c340443fd7","GBP/USD", "Bid", 1.32567, 7, Timestamp.valueOf("2020-01-01 22:02:50.136000"), "add")));


        HashMap<String, Object> innerMap_1 = new HashMap<String, Object>();
        HashMap<String, Object> innerMap_2 = new HashMap<String, Object>();
        innerMap_2.put("side", "Bid");
        innerMap_2.put("price", 1.32568D);
        innerMap_2.put("total_size", 10L);
        innerMap_2.put("number_of_orders", 2L);

        innerMap_1.put("side", "Ask");
        innerMap_1.put("price", 1.32569D);
        innerMap_1.put("total_size", 7L);
        innerMap_1.put("number_of_orders", 2L);
        
        collectData.put("orderArrayList", orderArrayList);
        collectData.put("filterAsk", filterAsk);
        collectData.put("filterBid", filterBid);
        collectData.put("orderArrayListAction", orderArrayListAction);
        collectData.put("inner_map_1", innerMap_1);
        collectData.put("inner_map_2", innerMap_2);


    return collectData;
    }

    @Test
    public void testTopNOfTheBook(){

        HashMap<String, Object> collectData =  getTestDataTopNOfTheBook();
        ArrayList<OrderBook> orderArrayList = (ArrayList<OrderBook>) collectData.get("orderArrayList");
        ArrayList<OrderBook> filterBid = (ArrayList<OrderBook>) collectData.get("filterBid");
        ArrayList<OrderBook> filterAsk = (ArrayList<OrderBook>) collectData.get("filterAsk");
        ArrayList<OrderBook> orderArrayListAction = (ArrayList<OrderBook>) collectData.get("orderArrayListAction");
        TreeMap<Double, HashMap<String, Object>> inner_key_map_ask = (TreeMap<Double, HashMap<String, Object>>) collectData.get("inner_map_ask");
        TreeMap<Double, HashMap<String, Object>> inner_key_map_bid = (TreeMap<Double, HashMap<String, Object>>) collectData.get("inner_map_bid");


        Map<Double, Long> bidPriceLotSize = new HashMap<Double, Long>();
        bidPriceLotSize.put(1.32568D, 10L);
        bidPriceLotSize.put(1.32567D, 10L);

        Map<Double, Long> askPriceLotSize = new HashMap<Double, Long>();
        askPriceLotSize.put(1.32569D, 7L);
        askPriceLotSize.put(1.32737D, 15L);
        askPriceLotSize.put(1.32687D, 6L);

        Map<Double, Long> countBidOrders = new HashMap<Double, Long>();
        countBidOrders.put(1.32568D, 2L);
        countBidOrders.put(1.32567D, 2L);

        Map<Double, Long> countAskOrders = new HashMap<Double, Long>();
        countAskOrders.put(1.32569D, 2L);
        countAskOrders.put(1.32737D, 2L);
        countAskOrders.put(1.32687D, 1L);


        Error getAllDataError = new Error(new Date(), "No data found", "ML102");
        ArrayList<Error> listofErrors = new ArrayList<Error>();
        listofErrors.add(getAllDataError);
        UtilityResponse bidUtilFilter = new UtilityResponse(null, null, filterBid, null);
        UtilityResponse askUtilFilter = new UtilityResponse(null, null, filterAsk, null);
        UtilityResponse bidLotSum = new UtilityResponse(bidPriceLotSize, null, null, null);
        UtilityResponse askLotSum = new UtilityResponse(askPriceLotSize, null, null, null);
        UtilityResponse bidCnt = new UtilityResponse(null, countBidOrders, null, null);
        UtilityResponse askCnt = new UtilityResponse(null, countAskOrders, null, null);
        UtilityResponse actionFilter = new UtilityResponse(null, null, orderArrayListAction, null);
        when(dataManipulationService.getAllData().getOrderBooks()).thenReturn(actionFilter.getArrayListOrderBook());
        when(utilities.filterAction(orderArrayList, "delete")).thenReturn(actionFilter);
        when(utilities.filterSide(orderArrayList, "Bid")).thenReturn(bidUtilFilter);
        when(utilities.filterSide(orderArrayList, "Ask")).thenReturn(askUtilFilter);
        when(utilities.groupByPriceLotSum(filterAsk)).thenReturn(bidLotSum);
        when(utilities.groupByPriceLotSum(filterBid)).thenReturn(askLotSum);
        when(utilities.groupByPriceCountOrders(filterAsk)).thenReturn(bidCnt);
        when(utilities.groupByPriceCountOrders(filterBid)).thenReturn(askCnt);

        HashMap<String, TreeMap<Double, HashMap<String, Object>>> topNOfTheBook = new HashMap<String, TreeMap<Double, HashMap<String, Object>>>();

        topNOfTheBook.put("Ask", inner_key_map_ask);
        topNOfTheBook.put("Bid", inner_key_map_bid);

        TopNOfTheBookResponse expectedOutput = new TopNOfTheBookResponse(null, topNOfTheBook);

        HashMap<String, TreeMap<Double, HashMap<String, Object>>> outputMap = dataManipulationService.getTopNOrders(2).getTopNOfTheBook();
        Set<String> outMapKeys = outputMap.keySet();
        Set<String> expectedMapKeys = expectedOutput.getTopNOfTheBook().keySet();

        // assertEquals(expectedMapKeys, outMapKeys); // Remove this**
        for (String key : outputMap.keySet()) {
            TreeMap<Double, HashMap<String, Object>> outTMap = outputMap.get(key);
            TreeMap<Double, HashMap<String, Object>> expectedTMap = expectedOutput.getTopNOfTheBook().get(key);
            for (Double key_tmap : outTMap.keySet()) {
                HashMap<String, Object> in_map = outTMap.get(key_tmap);
                HashMap<String, Object> in_map_exp = expectedTMap.get(key_tmap);
                for (String key_in : in_map_exp.keySet()) {
                    assertEquals(in_map_exp.get(key_in), in_map.get(key_in));
                }
            }
        }

    }


    private HashMap<String, Object> getTestDataTopNOfTheBook(){
        HashMap<String, Object> collectData = new HashMap<String, Object>();
        ArrayList<OrderBook> orderArrayList =
                new ArrayList<>(Arrays.asList(new OrderBook("1f07623c-332c-4cb7-83bf-ebef38684a63","GBP/USD","Ask", 1.32737, 9, Timestamp.valueOf("2020-01-01 22:01:30.485000"), "modify"),
                        new OrderBook("20e13c0f-0f45-434e-9a02-539c4ed6e639","GBP/USD", "Ask", 1.32687, 6, Timestamp.valueOf("2020-01-01 22:02:31.163000"), "add"),
                        new OrderBook("fc311112-93d7-486b-b4fa-e096c3224520","GBP/USD", "Ask", 1.32737, 6, Timestamp.valueOf("2020-01-01 22:02:37.558000"), "modify"),
                        new OrderBook("d560c699-1cef-4788-83eb-2efb4ee8fddf","GBP/USD", "Ask", 1.32569, 1, Timestamp.valueOf("2020-01-01 22:02:45.147000"), "add"),
                        new OrderBook("f9f398e3-19cb-4068-86cb-02af9fb87724","GBP/USD", "Ask", 1.32569, 6, Timestamp.valueOf("2020-01-01 22:02:45.571000"), "add"),
                        new OrderBook("4f928660-e830-4ab4-9559-94da8b5d2071","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.571000"), "add"),
                        new OrderBook("528d441e-1680-494f-85c2-b7d2920c3ef4","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.677000"), "modify"),
                        new OrderBook("e144661b-85fc-4f38-985d-91e903ab5cba","GBP/USD", "Bid", 1.32568, 9, Timestamp.valueOf("2020-01-01 22:02:47.361000"), "delete"),
                        new OrderBook("6adaf204-c499-4bda-9146-a053a27c8c77","GBP/USD", "Bid", 1.32567, 3, Timestamp.valueOf("2020-01-01 22:02:49.927000"), "add"),
                        new OrderBook("53995a6e-70a6-4b32-863a-40c340443fd7","GBP/USD", "Bid", 1.32567, 7, Timestamp.valueOf("2020-01-01 22:02:50.136000"), "add")));

        ArrayList<OrderBook> orderArrayListAction =
                new ArrayList<>(Arrays.asList(new OrderBook("1f07623c-332c-4cb7-83bf-ebef38684a63","GBP/USD","Ask", 1.32737, 9, Timestamp.valueOf("2020-01-01 22:01:30.485000"), "modify"),
                        new OrderBook("20e13c0f-0f45-434e-9a02-539c4ed6e639","GBP/USD", "Ask", 1.32687, 6, Timestamp.valueOf("2020-01-01 22:02:31.163000"), "add"),
                        new OrderBook("fc311112-93d7-486b-b4fa-e096c3224520","GBP/USD", "Ask", 1.32737, 6, Timestamp.valueOf("2020-01-01 22:02:37.558000"), "modify"),
                        new OrderBook("d560c699-1cef-4788-83eb-2efb4ee8fddf","GBP/USD", "Ask", 1.32569, 1, Timestamp.valueOf("2020-01-01 22:02:45.147000"), "add"),
                        new OrderBook("f9f398e3-19cb-4068-86cb-02af9fb87724","GBP/USD", "Ask", 1.32569, 6, Timestamp.valueOf("2020-01-01 22:02:45.571000"), "add"),
                        new OrderBook("4f928660-e830-4ab4-9559-94da8b5d2071","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.571000"), "add"),
                        new OrderBook("528d441e-1680-494f-85c2-b7d2920c3ef4","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.677000"), "modify"),
                        new OrderBook("6adaf204-c499-4bda-9146-a053a27c8c77","GBP/USD", "Bid", 1.32567, 3, Timestamp.valueOf("2020-01-01 22:02:49.927000"), "add"),
                        new OrderBook("53995a6e-70a6-4b32-863a-40c340443fd7","GBP/USD", "Bid", 1.32567, 7, Timestamp.valueOf("2020-01-01 22:02:50.136000"), "add")));

        ArrayList<OrderBook> filterAsk = new ArrayList<>(Arrays.asList(new OrderBook("1f07623c-332c-4cb7-83bf-ebef38684a63","GBP/USD","Ask", 1.32737, 9, Timestamp.valueOf("2020-01-01 22:01:30.485000"), "modify"),
                new OrderBook("20e13c0f-0f45-434e-9a02-539c4ed6e639","GBP/USD", "Ask", 1.32687, 6, Timestamp.valueOf("2020-01-01 22:02:31.163000"), "add"),
                new OrderBook("fc311112-93d7-486b-b4fa-e096c3224520","GBP/USD", "Ask", 1.32737, 6, Timestamp.valueOf("2020-01-01 22:02:37.558000"), "modify"),
                new OrderBook("d560c699-1cef-4788-83eb-2efb4ee8fddf","GBP/USD", "Ask", 1.32569, 1, Timestamp.valueOf("2020-01-01 22:02:45.147000"), "add"),
                new OrderBook("f9f398e3-19cb-4068-86cb-02af9fb87724","GBP/USD", "Ask", 1.32569, 6, Timestamp.valueOf("2020-01-01 22:02:45.571000"), "add")
        ));
        ArrayList<OrderBook> filterBid =
                new ArrayList<>(Arrays.asList(new OrderBook("4f928660-e830-4ab4-9559-94da8b5d2071","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.571000"), "add"),
                        new OrderBook("528d441e-1680-494f-85c2-b7d2920c3ef4","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.677000"), "modify"),
                        new OrderBook("e144661b-85fc-4f38-985d-91e903ab5cba","GBP/USD", "Bid", 1.32568, 9, Timestamp.valueOf("2020-01-01 22:02:47.361000"), "delete"),
                        new OrderBook("6adaf204-c499-4bda-9146-a053a27c8c77","GBP/USD", "Bid", 1.32567, 3, Timestamp.valueOf("2020-01-01 22:02:49.927000"), "add"),
                        new OrderBook("53995a6e-70a6-4b32-863a-40c340443fd7","GBP/USD", "Bid", 1.32567, 7, Timestamp.valueOf("2020-01-01 22:02:50.136000"), "add")));

        TreeMap<Double, HashMap<String, Object>> inner_key_map_bid = new TreeMap<Double, HashMap<String, Object>>();
        TreeMap<Double, HashMap<String, Object>> inner_key_map_ask = new TreeMap<Double, HashMap<String, Object>>();
        HashMap<String, Object> innerMap_Bid1 = new HashMap<String, Object>();
        HashMap<String, Object> innerMap_Bid2 = new HashMap<String, Object>();
        HashMap<String, Object> innerMap_Ask1 = new HashMap<String, Object>();
        HashMap<String, Object> innerMap_Ask2 = new HashMap<String, Object>();

        innerMap_Bid1.put("price", 1.32568D);
        innerMap_Bid1.put("total_size", 10L);
        innerMap_Bid1.put("total_orders", 2L);

        innerMap_Bid2.put("price", 1.32567D);
        innerMap_Bid2.put("total_size", 10L);
        innerMap_Bid2.put("total_orders", 2L);

        innerMap_Ask2.put("price", 1.32569D);
        innerMap_Ask2.put("total_size", 7L);
        innerMap_Ask2.put("total_orders", 2L);

        innerMap_Ask1.put("price", 1.32687D);
        innerMap_Ask1.put("total_size", 6L);
        innerMap_Ask1.put("total_orders", 1L);

        inner_key_map_ask.put(1.32569D, innerMap_Ask2);
        inner_key_map_ask.put(1.32687D, innerMap_Ask1);

        inner_key_map_bid.put( 1.32568D, innerMap_Bid1);
        inner_key_map_bid.put(1.32567D, innerMap_Bid2);

        collectData.put("orderArrayList", orderArrayList);
        collectData.put("filterAsk", filterAsk);
        collectData.put("filterBid", filterBid);
        collectData.put("orderArrayListAction", orderArrayListAction);
        collectData.put("inner_map_ask", inner_key_map_ask);
        collectData.put("inner_map_bid", inner_key_map_bid);

        return collectData;
    }

     @Test
    public void testTopOfTheBookNoData(){

        TopOfTheBookResponse actual = new TopOfTheBookResponse();
        when(orderRepository.findAll()).thenReturn(new ArrayList<>());
        Error expectedError = new Error(new Date(), "No data found", "ML102");
        actual = dataManipulationService.getTopOfTheBookOrders();
        ArrayList<Error> actualError = actual.getErrors();
        assertEquals(expectedError.getCode(), actual.getErrors().get(0).getCode());
    }

    @Test
    public void testTopNOfTheBookNoData(){

        when(orderRepository.findAll()).thenReturn(new ArrayList<>());
        Error expectedError = new Error(new Date(), "No data found", "ML103");
        TopNOfTheBookResponse actual = new TopNOfTheBookResponse();
        actual = dataManipulationService.getTopNOrders(2);
        ArrayList<Error> actualError = actual.getErrors();
        assertEquals(expectedError.getCode(), actual.getErrors().get(0).getCode());
    }








    // This is end of class
}