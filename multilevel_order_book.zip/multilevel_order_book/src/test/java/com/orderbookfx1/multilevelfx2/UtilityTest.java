package com.orderbookfx1.multilevelfx2;


import com.orderbookfx1.multilevelfx2.exceptions.Error;
import com.orderbookfx1.multilevelfx2.models.OrderBook;
import com.orderbookfx1.multilevelfx2.repository.OrderRepository;
import com.orderbookfx1.multilevelfx2.models.UtilityResponse;
import com.orderbookfx1.multilevelfx2.resources.Utility;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;


//@RunWith(MockitoJUnitRunner.class)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Utility.class, UtilityResponse.class})
//@AutoConfigureMockMvc
public class UtilityTest {

    /**
     * Test to check the functionalities of the utility function
     * 1.
     */

    @Autowired
    private Utility utilities;

    // Mock the repository
    @MockBean
    private OrderRepository orderRepository;

    @Test
    public void testSideFiltering(){

        ArrayList<OrderBook> orderArrayList = new ArrayList<>(Arrays.asList(new OrderBook("order_1", "GBPUSD","Bid",11.0, 6, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add"),
                new OrderBook("order_2","GBPUSD", "Ask", 12.0, 5, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add")));
        when(orderRepository.findAll()).thenReturn(orderArrayList);
        ArrayList<OrderBook> orders = (ArrayList<OrderBook>) orderRepository.findAll();
        ArrayList<OrderBook> expectedOutput =
                new ArrayList<>(Arrays.asList(new OrderBook("order_1","GBPUSD","Bid",11.0, 6, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add")));

        assertEquals(expectedOutput,
                utilities.filterSide(orders, "Bid").getArrayListOrderBook());
    }

    @Test
    public void testPriceLotSizeGroupby(){
        ArrayList<OrderBook> orderArrayList = new ArrayList<>(Arrays.asList(new OrderBook("order_1","GBPUSD","Bid",11.0, 6, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add"),
                new OrderBook("order_2","GBPUSD", "Ask", 12.0, 5, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add"),
                new OrderBook("order_3","GBPUSD", "Bid", 11.0, 15, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add"),
                new OrderBook("order_4","GBPUSD", "Ask", 12.0, 10, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add")));

        Map<Double, Long> expectedOutput = new HashMap<Double, Long>();
        long count_11 = 21L;
        long count_12 = 15L;
        expectedOutput.put(11.0, count_11);
        expectedOutput.put(12.0, count_12);

        assertEquals(expectedOutput,
                utilities.groupByPriceLotSum(orderArrayList).getGroupBySum());
    }

    @Test
    public void testPriceCountOrders() throws Exception{
        ArrayList<OrderBook> orderArrayList = new ArrayList<>(Arrays.asList(new OrderBook("order_1","GBPUSD","Bid",11.0, 6, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add"),
                new OrderBook("order_2","GBPUSD", "Ask", 12.0, 5, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add"),
                new OrderBook("order_3","GBPUSD", "Bid", 11.0, 15, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add"),
                new OrderBook("order_4","GBPUSD", "Ask", 12.0, 10, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add")));


        Map<Double, Long> expectedOutput = new HashMap<Double, Long>();
        long count_11 = 2L;
        long count_12 = 2L;
        expectedOutput.put(11.0, count_11);
        expectedOutput.put(12.0, count_12);

        assertEquals(expectedOutput,
                utilities.groupByPriceCountOrders(orderArrayList).getGroupByCount());
    }

    @Test
    public void testActionFiltering(){

        ArrayList<OrderBook> orderArrayList =
                new ArrayList<>(Arrays.asList(new OrderBook("1f07623c-332c-4cb7-83bf-ebef38684a63","GBP/USD","Ask", 1.32737, 9, Timestamp.valueOf("2020-01-01 22:01:30.485000"), "modify"),
                        new OrderBook("20e13c0f-0f45-434e-9a02-539c4ed6e639","GBP/USD", "Ask", 1.32687, 6, Timestamp.valueOf("2020-01-01 22:02:31.163000"), "add"),
                        new OrderBook("fc311112-93d7-486b-b4fa-e096c3224520","GBP/USD", "Ask", 1.32737, 6, Timestamp.valueOf("2020-01-01 22:02:37.558000"), "modify"),
                        new OrderBook("d560c699-1cef-4788-83eb-2efb4ee8fddf","GBP/USD", "Ask", 1.32569, 1, Timestamp.valueOf("2020-01-01 22:02:45.147000"), "add"),
                        new OrderBook("f9f398e3-19cb-4068-86cb-02af9fb87724","GBP/USD", "Ask", 1.32569, 6, Timestamp.valueOf("2020-01-01 22:02:45.571000"), "add"),
                        new OrderBook("4f928660-e830-4ab4-9559-94da8b5d2071","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.571000"), "add"),
                        new OrderBook("528d441e-1680-494f-85c2-b7d2920c3ef4","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.677000"), "modify"),
                        new OrderBook("e144661b-85fc-4f38-985d-91e903ab5cba","GBP/USD", "Bid", 1.32568, 9, Timestamp.valueOf("2020-01-01 22:02:47.361000"), "delete"),
                        new OrderBook("6adaf204-c499-4bda-9146-a053a27c8c77","GBP/USD", "Bid", 1.32567, 3, Timestamp.valueOf("2020-01-01 22:02:49.927000"), "add"),
                        new OrderBook("53995a6e-70a6-4b32-863a-40c340443fd7","GBP/USD", "Bid", 1.32567, 7, Timestamp.valueOf("2020-01-01 22:02:50.136000"), "add")));
        when(orderRepository.findAll()).thenReturn(orderArrayList);
        ArrayList<OrderBook> orders = (ArrayList<OrderBook>) orderRepository.findAll();
        ArrayList<OrderBook> expectedOutput =
                        new ArrayList<>(Arrays.asList(new OrderBook("1f07623c-332c-4cb7-83bf-ebef38684a63","GBP/USD","Ask", 1.32737, 9, Timestamp.valueOf("2020-01-01 22:01:30.485000"), "modify"),
                                new OrderBook("20e13c0f-0f45-434e-9a02-539c4ed6e639","GBP/USD", "Ask", 1.32687, 6, Timestamp.valueOf("2020-01-01 22:02:31.163000"), "add"),
                                new OrderBook("fc311112-93d7-486b-b4fa-e096c3224520","GBP/USD", "Ask", 1.32737, 6, Timestamp.valueOf("2020-01-01 22:02:37.558000"), "modify"),
                                new OrderBook("d560c699-1cef-4788-83eb-2efb4ee8fddf","GBP/USD", "Ask", 1.32569, 1, Timestamp.valueOf("2020-01-01 22:02:45.147000"), "add"),
                                new OrderBook("f9f398e3-19cb-4068-86cb-02af9fb87724","GBP/USD", "Ask", 1.32569, 6, Timestamp.valueOf("2020-01-01 22:02:45.571000"), "add"),
                                new OrderBook("4f928660-e830-4ab4-9559-94da8b5d2071","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.571000"), "add"),
                                new OrderBook("528d441e-1680-494f-85c2-b7d2920c3ef4","GBP/USD", "Bid", 1.32568, 5, Timestamp.valueOf("2020-01-01 22:02:46.677000"), "modify"),
                                new OrderBook("6adaf204-c499-4bda-9146-a053a27c8c77","GBP/USD", "Bid", 1.32567, 3, Timestamp.valueOf("2020-01-01 22:02:49.927000"), "add"),
                                new OrderBook("53995a6e-70a6-4b32-863a-40c340443fd7","GBP/USD", "Bid", 1.32567, 7, Timestamp.valueOf("2020-01-01 22:02:50.136000"), "add")));
        assertEquals(expectedOutput,
                utilities.filterAction(orders, "delete").getArrayListOrderBook());
    }

    @Test
    public void testActionFilteringNoData(){
        when(orderRepository.findAll()).thenReturn(new ArrayList<>());
        ArrayList<OrderBook> orders = (ArrayList<OrderBook>) orderRepository.findAll();
        Error expectedError = new Error(new Date(), "Empty list passed to getMin", "UL105");
        UtilityResponse actual = utilities.filterAction(orders, "delete");
        ArrayList<Error> actualError = actual.getErrors();

        assertEquals(expectedError.getCode(), actual.getErrors().get(0).getCode());
    }

    @Test
    public void testSideFilteringNoData(){
        when(orderRepository.findAll()).thenReturn(new ArrayList<>());
        ArrayList<OrderBook> orders = (ArrayList<OrderBook>) orderRepository.findAll();
        Error expectedError = new Error(new Date(), "Empty list passed to getMin", "UL104");
        UtilityResponse actual = utilities.filterSide(orders, "Bid");
        ArrayList<Error> actualError = actual.getErrors();

        assertEquals(expectedError.getCode(), actual.getErrors().get(0).getCode());
    }

    @Test
    public void testOrderCountNoData(){
        when(orderRepository.findAll()).thenReturn(new ArrayList<>());
        ArrayList<OrderBook> orders = (ArrayList<OrderBook>) orderRepository.findAll();
        Error expectedError = new Error(new Date(), "Empty list passed to getMin", "UL101");
        UtilityResponse actual = utilities.groupByPriceCountOrders(orders);
        ArrayList<Error> actualError = actual.getErrors();

        assertEquals(expectedError.getCode(), actual.getErrors().get(0).getCode());
    }

    @Test
    public void testOrderSizeNoData(){
        when(orderRepository.findAll()).thenReturn(new ArrayList<>());
        ArrayList<OrderBook> orders = (ArrayList<OrderBook>) orderRepository.findAll();
        Error expectedError = new Error(new Date(), "Empty list passed to getMin", "UL102");
        UtilityResponse actual = utilities.groupByPriceLotSum(orders);
        ArrayList<Error> actualError = actual.getErrors();

        assertEquals(expectedError.getCode(), actual.getErrors().get(0).getCode());
    }



}
