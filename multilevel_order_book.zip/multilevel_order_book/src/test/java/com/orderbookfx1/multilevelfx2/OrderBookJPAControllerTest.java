package com.orderbookfx1.multilevelfx2;

import ch.qos.logback.classic.spi.LoggingEventVO;
import com.orderbookfx1.multilevelfx2.controller.OrderBookJPAController;
import com.orderbookfx1.multilevelfx2.models.*;
import com.orderbookfx1.multilevelfx2.repository.OrderRepository;
import com.orderbookfx1.multilevelfx2.resources.Utility;
import com.orderbookfx1.multilevelfx2.services.DataManipulationService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.runner.RunWith;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(OrderBookJPAController.class)
public class OrderBookJPAControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private OrderRepository orderRepository;
    @MockBean
    private DataManipulationService dataManipulationService;
    @MockBean
    private UtilityResponse utilityResponse;
    @MockBean
    private Utility utility;
    @InjectMocks
    OrderBookJPAController orderBookJPAController;


    // Test to check response payload from service

    @Test
    public void orderbookAllDataControllerTest() throws Exception {
        ArrayList<OrderBook> orderBookArrayList = new ArrayList<OrderBook>();
        orderBookArrayList.add(new OrderBook("order_1", "GBPUSD","Bid", 10.0, 2, Timestamp.valueOf("2020-01-01 22:01:30.485"),"add"));
        OrderBookResponse orderBookResponse = new OrderBookResponse();
        orderBookResponse.setOrderBooks(orderBookArrayList);
        orderBookResponse.setErrors(null);
        when(dataManipulationService.getAllData()).thenReturn(orderBookResponse);

        RequestBuilder request = MockMvcRequestBuilders
                .get("/jpa/orders")
                .accept(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk()) // Checking for status
                .andExpect(content().json("{orderBooks:[{id:order_1,sym:GBPUSD, side:Bid,price:10.0,lots:2, timestamp:'2020-01-01T22:01:30.485+0000', action:add}],errors:null}")) // For real response use content.json
                .andReturn();

    }

}
