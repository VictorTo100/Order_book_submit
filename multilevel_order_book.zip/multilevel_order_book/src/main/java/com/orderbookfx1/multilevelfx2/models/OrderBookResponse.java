package com.orderbookfx1.multilevelfx2.models;

import com.orderbookfx1.multilevelfx2.exceptions.Error;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public class OrderBookResponse {

    private ArrayList<OrderBook> orderBooks;
    private ArrayList<Error> errors;

    public ArrayList<OrderBook> getOrderBooks() {
        return orderBooks;
    }

    public void setOrderBooks(ArrayList<OrderBook> orderBooks) {
        this.orderBooks = orderBooks;
    }

    public ArrayList<Error> getErrors() {
        return errors;
    }

    public void setErrors(ArrayList<Error> errors) {
        this.errors = errors;
    }
}
