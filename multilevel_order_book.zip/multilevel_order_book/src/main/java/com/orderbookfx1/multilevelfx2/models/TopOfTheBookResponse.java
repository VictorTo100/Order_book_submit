package com.orderbookfx1.multilevelfx2.models;

import com.orderbookfx1.multilevelfx2.exceptions.Error;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;

@Component
public class TopOfTheBookResponse {

    /**
     * This Class provides the structure for the Top Of The Book Response object
     * 1. To store top order from the data along with their information
     * 2. Handle error message
     */

    private ArrayList<Error> errors;

    public TopOfTheBookResponse(ArrayList<Error> errors, HashMap<String, HashMap<String, Object>> topOfTheBook) {
        this.errors = errors;
        this.topOfTheBook = topOfTheBook;
    }

    public TopOfTheBookResponse() {

    }

    private HashMap<String, HashMap<String, Object>> topOfTheBook;


    public ArrayList<Error> getErrors() {
        return errors;
    }

    public void setErrors(ArrayList<Error> errors) {
        this.errors = errors;
    }

    public HashMap<String, HashMap<String, Object>> getTopOfTheBook() {
        return topOfTheBook;
    }

    public void setTopOfTheBook(HashMap<String, HashMap<String, Object>> topOfTheBook) {
        this.topOfTheBook = topOfTheBook;
    }


}
