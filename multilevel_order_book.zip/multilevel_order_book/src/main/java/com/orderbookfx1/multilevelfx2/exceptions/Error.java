package com.orderbookfx1.multilevelfx2.exceptions;

import java.util.Date;

public class Error {

    private String code;
    private Date timestamp;
    private String message;

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    // constructor with fields
    public Error(Date timestamp, String message, String code) {
        this.timestamp = timestamp;
        this.message = message;
        this.code = code;
    }

}
