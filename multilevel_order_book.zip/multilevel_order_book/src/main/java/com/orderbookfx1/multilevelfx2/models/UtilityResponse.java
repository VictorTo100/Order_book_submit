package com.orderbookfx1.multilevelfx2.models;

import com.orderbookfx1.multilevelfx2.exceptions.Error;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Map;

@Component
public class UtilityResponse {

    /**
     * This Class provides the structure for the Utility response objects
     * 1. To store total lot size
     * 2. Number of order at price point
     * 3. List of Orderbook
     * 4. Handle error message
     */

    private Map<Double, Long> groupBySum;
    private Map<Double, Long> groupByCount;
    private ArrayList<OrderBook> arrayListOrderBook;
    private ArrayList<Error> errors;

    // Default constructor
    public UtilityResponse(){

    }

    public UtilityResponse(Map<Double, Long> groupBySum, Map<Double, Long> groupByCount, ArrayList<OrderBook> arrayListOrderBook, ArrayList<Error> errors) {
        this.groupBySum = groupBySum;
        this.groupByCount = groupByCount;
        this.arrayListOrderBook = arrayListOrderBook;
        this.errors = errors;
    }

    public ArrayList<OrderBook> getArrayListOrderBook() {
        return arrayListOrderBook;
    }

    public void setArrayListOrderBook(ArrayList<OrderBook> arrayListOrderBook) {
        this.arrayListOrderBook = arrayListOrderBook;
    }

    public Map<Double, Long> getGroupBySum() {
        return groupBySum;
    }

    public void setGroupBySum(Map<Double, Long> groupBySum) {
        this.groupBySum = groupBySum;
    }

    public Map<Double, Long> getGroupByCount() {
        return groupByCount;
    }

    public void setGroupByCount(Map<Double, Long> groupByCount) {
        this.groupByCount = groupByCount;
    }

    public ArrayList<Error> getErrors() {
        return errors;
    }

    public void setErrors(ArrayList<Error> errors) {
        this.errors = errors;
    }



}
