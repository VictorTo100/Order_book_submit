package com.orderbookfx1.multilevelfx2.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;


@Entity
@Table(name="order_book")
public class OrderBook {

   @Id
    private String id;
    private String sym;
    private String side;
    private Timestamp timestamp;
    private double price;
    private int lots;
    private String action;

    public OrderBook(){
    }

    public OrderBook(String id, String sym, String side, double price, int lots,Timestamp timestamp, String action) {
        this.id = id;
        this.sym = sym;
        this.side = side;
        this.timestamp = timestamp;
        this.price = price;
        this.lots = lots;
        this.action = action;
    }

    @Column(name = "ID", nullable = false)
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    @Column(name = "SIDE", nullable = false)
    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    @Column(name = "TIMESTAMP", nullable = false)
    public Timestamp getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    @Column(name = "PRICE", nullable = false)
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }

    @Column(name = "LOTS", nullable = false)
    public int getLots() {
        return lots;
    }
    public void setLots(int lots) {
        this.lots = lots;
    }

    @Column(name = "SYM", nullable = false)
    public String getSym() { return sym; }
    public void setSym(String sym) {this.sym = sym; }

    @Column(name = "ACTION", nullable = false)
    public String getAction() {return action; }
    public void setAction(String action) { this.action = action; }

    @Override
    public String toString() {
        return "OrderBook{" +
                "id='" + id + '\'' +
                ", sym='" + sym + '\'' +
                ", side='" + side + '\'' +
                ", timestamp=" + timestamp +
                ", price=" + price +
                ", lots=" + lots +
                ", action='" + action + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        OrderBook orders = (OrderBook) o;
        return id.equals(orders.id) &&
                side.equals(orders.side) &&
                price == orders.price &&
                lots == orders.lots &&
                sym == orders.sym &&
                action == orders.action &&
                timestamp.equals(orders.timestamp);
    }

}
