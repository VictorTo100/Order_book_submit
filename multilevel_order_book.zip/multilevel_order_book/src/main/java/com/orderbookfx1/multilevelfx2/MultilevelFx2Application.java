package com.orderbookfx1.multilevelfx2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultilevelFx2Application {

	public static void main(String[] args) {
		SpringApplication.run(MultilevelFx2Application.class, args);
	}

}
