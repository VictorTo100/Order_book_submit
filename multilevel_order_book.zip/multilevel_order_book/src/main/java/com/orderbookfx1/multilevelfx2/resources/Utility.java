package com.orderbookfx1.multilevelfx2.resources;

import com.orderbookfx1.multilevelfx2.exceptions.Error;
import com.orderbookfx1.multilevelfx2.models.OrderBook;
import com.orderbookfx1.multilevelfx2.repository.OrderRepository;
import com.orderbookfx1.multilevelfx2.models.UtilityResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;

@Component
public class Utility {
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private UtilityResponse utilityResponse, sideFilter, priceLotSum, priceCountOrders;

    /**
     * This method is used to filter order by their side
     * @param listOfOrderBook This is a list of orderbook objects
     * @param orderside  This is side of the order: "Bid". "Ask"
     * @return list of orderbook objects with respective side
     */

    public UtilityResponse filterSide(ArrayList<OrderBook> listOfOrderBook, String orderside){
        UtilityResponse sideFilter = new UtilityResponse();
        // Check if the data empty; this is additional
        if (!listOfOrderBook.isEmpty()) {
            sideFilter.setArrayListOrderBook(listOfOrderBook.stream()
                    .filter(b -> b.getSide().equals(orderside))
                    .collect(Collectors.toCollection(ArrayList::new)));
        }else{
            Error getAllDataError = new Error(new Date(), "Empty list passed to getMin", "UL104");
            ArrayList<Error> listofErrors = new ArrayList<Error>();
            listofErrors.add(getAllDataError);
            sideFilter.setErrors(listofErrors);
        }
        return sideFilter;
    }

    /**
     * This method is used to filter order by their side
     * @param listOfOrderBook This is a list of orderbook objects
     * @param action  This is the action assumed in the actual datafeed orderbook
     * @return list of orderbook objects with order "add" and "modified"
     */
    public UtilityResponse filterAction(ArrayList<OrderBook> listOfOrderBook, String action){
        UtilityResponse actionFilter = new UtilityResponse();
        if (!listOfOrderBook.isEmpty()) {
            actionFilter.setArrayListOrderBook(listOfOrderBook.stream()
                    .filter(b -> (!b.getAction().equals(action)))
                    .collect(Collectors.toCollection(ArrayList::new)));
        }else{
            Error getAllDataError = new Error(new Date(), "Empty list passed to getMin", "UL105");
            ArrayList<Error> listofErrors = new ArrayList<Error>();
            listofErrors.add(getAllDataError);
            actionFilter.setErrors(listofErrors);
        }
        return actionFilter;
    }

    /******************************************
     * Group by utilities
     ******************************************/

    /**
     * This methods does aggregation at price level and return the told lot size available
     * The function make use of streams and group by functions in collectors
     */

    public UtilityResponse groupByPriceLotSum(ArrayList<OrderBook> orderBookArraySideList){
        UtilityResponse priceLotSum = new UtilityResponse();
        if (!orderBookArraySideList.isEmpty()) {
            // Use of Collector's group by utilities
            priceLotSum.setGroupBySum(orderBookArraySideList.stream()
                    .collect(Collectors.groupingBy(OrderBook::getPrice, summingLong(OrderBook::getLots))));
        }else{
            Error getAllDataError = new Error(new Date(), "Empty list passed to getMin", "UL102");
            ArrayList<Error> listofErrors = new ArrayList<Error>();
            listofErrors.add(getAllDataError);
            priceLotSum.setErrors(listofErrors);
        }
        return priceLotSum;
    }

    /**
     * This methods does aggregation at price level and return the told lot size available
     * The function make use of streams and group by functions in collectors
     *
     */

    // Group by by price and get total number of trades
    public UtilityResponse groupByPriceCountOrders(ArrayList<OrderBook> orderBookArraySideList) {
        UtilityResponse priceCountOrders = new UtilityResponse();
        if (!orderBookArraySideList.isEmpty()) {
            priceCountOrders.setGroupByCount(orderBookArraySideList.stream()
                    .collect(Collectors.groupingBy(OrderBook::getPrice, counting())));
        }else{
            Error getAllDataError = new Error(new Date(), "Empty list passed to getMin", "UL101");
            ArrayList<Error> listofErrors = new ArrayList<Error>();
            listofErrors.add(getAllDataError);
            priceCountOrders.setErrors(listofErrors);
        }
        return  priceCountOrders;

    }

}
