package com.orderbookfx1.multilevelfx2.models;

import com.orderbookfx1.multilevelfx2.exceptions.Error;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

@Component
public class TopNOfTheBookResponse {

    /**
     * This Class provides the structure for the Top N Of The Book Response object
     * 1. To store top order from the data along with their information
     * 2. Handle error message
     */
    public TopNOfTheBookResponse(){
    }

    public TopNOfTheBookResponse(ArrayList<Error> errors, HashMap<String, TreeMap<Double,HashMap<String, Object>>> topNOfTheBook) {
        this.topNOfTheBook = topNOfTheBook;
        this.errors = errors;
    }

    private HashMap<String, TreeMap<Double,HashMap<String, Object>>> topNOfTheBook;
    private ArrayList<Error> errors;

    public HashMap<String, TreeMap<Double,HashMap<String, Object>>> getTopNOfTheBook() {
        return topNOfTheBook;
    }

    public void setTopNOfTheBook(HashMap<String, TreeMap<Double,HashMap<String, Object>>> topNOfTheBook) {
        this.topNOfTheBook = topNOfTheBook;
    }

    public ArrayList<Error> getErrors() {
        return errors;
    }

    public void setErrors(ArrayList<Error> errors) {
        this.errors = errors;
    }



}
