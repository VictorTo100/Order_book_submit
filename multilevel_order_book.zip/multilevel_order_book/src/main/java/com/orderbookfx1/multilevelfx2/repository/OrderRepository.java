package com.orderbookfx1.multilevelfx2.repository;

import com.orderbookfx1.multilevelfx2.models.OrderBook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<OrderBook, String> {

}
