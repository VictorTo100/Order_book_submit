package com.orderbookfx1.multilevelfx2.controller;

import com.orderbookfx1.multilevelfx2.models.*;
import com.orderbookfx1.multilevelfx2.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.orderbookfx1.multilevelfx2.services.DataManipulationService;

@RestController
public class OrderBookJPAController {

    @Autowired
    private DataManipulationService dataManipulationService;
    @Autowired
    private OrderRepository orderRepository;

    // Get Orders
    //Retrieve all orders
    @GetMapping("/jpa/orders")
    public OrderBookResponse retrieveAllOrders() {
        OrderBookResponse allData = dataManipulationService.getAllData();
        return allData;
    }

    @GetMapping("/jpa/topofthebook")
    public TopOfTheBookResponse ordersByPrice() {
        TopOfTheBookResponse topOfTheBook = dataManipulationService.getTopOfTheBookOrders();

        return  topOfTheBook;
    }

    @GetMapping("/jpa/topNOrders/{level}")
    public TopNOfTheBookResponse nOrdersByPrice(@PathVariable int level) {
        TopNOfTheBookResponse topNOrders = dataManipulationService.getTopNOrders(level);

        return topNOrders;
    }

}
