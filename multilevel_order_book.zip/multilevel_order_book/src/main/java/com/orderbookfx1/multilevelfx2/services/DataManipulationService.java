package com.orderbookfx1.multilevelfx2.services;

import com.orderbookfx1.multilevelfx2.exceptions.Error;
import com.orderbookfx1.multilevelfx2.models.*;
import com.orderbookfx1.multilevelfx2.repository.OrderRepository;
import com.orderbookfx1.multilevelfx2.resources.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.*;

@Component
public class DataManipulationService {

    @Autowired
    private Utility utilities;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private OrderBookResponse orderBookResponse;
    @Autowired
    UtilityResponse utilityResponse;
    @Autowired
    private TopOfTheBookResponse storeTopOfTheBookResponse;
    @Autowired
    private TopNOfTheBookResponse storeTopNOfTheBookResponse;

    /**
     * Method to Retrieve all orders to simulate a feed of orders using JPA repository
     * It creats an ArrayList with relevant orderbook object for comsumption as well as
     * downstream task
     * This function filters order actions and only returns actions with add and modify
     * Returns: Object of type OrderbookReponse
     */

    public OrderBookResponse getAllData() {
        ArrayList<OrderBook> orderBookArrayList = new ArrayList<OrderBook>();
        OrderBookResponse orderBookAll = new OrderBookResponse();
        // Retrieve data from H2 DB using JPA repository
        if(!orderRepository.findAll().isEmpty()){
        for (OrderBook orders : orderRepository.findAll()) {
            String id = orders.getId();
            String side = orders.getSide();
            double price = orders.getPrice();
            int lots = orders.getLots();
            Timestamp timestamp = orders.getTimestamp();
            String sym = orders.getSym();
            String action = orders.getAction();
            orderBookArrayList.add(new OrderBook(id, sym, side, price, lots, timestamp, action));
        }
            Utility utilities_filer = new Utility();
            UtilityResponse orderBookArrayAction = new UtilityResponse();

            orderBookArrayAction = utilities_filer.filterAction(orderBookArrayList, "delete");
            orderBookAll.setOrderBooks(orderBookArrayAction.getArrayListOrderBook());

        }else{
        Error getAllDataError = new Error(new Date(), "No data found", "ML101");
        ArrayList<Error> listofErrors = new ArrayList<Error>();
        listofErrors.add(getAllDataError);
            orderBookAll.setErrors(listofErrors);
        }
        return orderBookAll;
    }

    /**
     * Method to fetch top of book order data
     * Return: Object of type TopOfTheOrderBookResponse
     *         Best order for for Bid(max price) and Ask(min price)
     * If only one side is available it will return data for only one side
     * The orders are aggregated at price point and give total lot size available
     * and the number of orders at that price
     * If there is no data an Error message will be returned with an error code
     * Error message is part of the TopOfTheOrderBookResponse
     */

    public TopOfTheBookResponse getTopOfTheBookOrders(){
        ArrayList<OrderBook> orderBookArrayList = new ArrayList<OrderBook>();
        OrderBookResponse orderBookResponse =  new OrderBookResponse();
        orderBookArrayList =  getAllData().getOrderBooks();
        UtilityResponse orderBookArrayListAction = new UtilityResponse();
        Utility utilities_filter = new Utility();
        if(orderBookArrayList!=null){
            // Filter data on order sides; Bid and Ask respectively
            UtilityResponse orderBookArrayListBid = new UtilityResponse();
            Utility utilitiesBid = new Utility();
            orderBookArrayListBid = utilitiesBid.filterSide(orderBookArrayList, "Bid");
            UtilityResponse orderBookArrayListAsk = new UtilityResponse();
            Utility utilitiesAsk = new Utility();
            orderBookArrayListAsk = utilitiesAsk.filterSide(orderBookArrayList, "Ask");
            HashMap<String, HashMap<String, Object>> topOfTheBook = new HashMap<String, HashMap<String, Object>>();
            // The main processing is done in this part of the code
            // The process function are common for bid and ask orders
            if (orderBookArrayListBid.getArrayListOrderBook().isEmpty()) {
                topOfTheBook.put("No_bids",processTopOfBookNoData(orderBookArrayListBid));
            } else{
                 topOfTheBook.put("Bid", processTopOfBookData(orderBookArrayListBid, "Bid"));
            }
            if (orderBookArrayListAsk.getArrayListOrderBook().isEmpty()){
                topOfTheBook.put("No_asks",processTopOfBookNoData(orderBookArrayListAsk));
            } else {
                topOfTheBook.put("Ask", processTopOfBookData(orderBookArrayListAsk, "Ask"));
            }
            storeTopOfTheBookResponse.setTopOfTheBook(topOfTheBook);
        }else{
            Error getAllDataError = new Error(new Date(), "No data found", "ML102");
            ArrayList<Error> listofErrors = new ArrayList<Error>();
            listofErrors.add(getAllDataError);
            storeTopOfTheBookResponse.setErrors(listofErrors);
        }

        return storeTopOfTheBookResponse;
    }

    /**
     * Method to fetch top N orders of the order book data
     * Arg: depth level
     * Return: Object of type TopOfTheOrderBookResponse
     *         Best order for for Bid(max price) and Ask(min price)
     * If only one side is available it will return data for only one side
     * The orders are aggregated at price point and give total lot size available
     * and the number of orders at that price
     * If less number of orders are available the queried the function will return
     * available data points
     * If there is no data an Error message will be returned with an error code
     * Error message is part of the TopOfTheOrderBookResponse
     * This function can be used as replacement for TopOfTheBook
     */
    public TopNOfTheBookResponse getTopNOrders(int level){

        ArrayList<OrderBook> orderBookArrayList = new ArrayList<OrderBook>();
        orderBookArrayList  = getAllData().getOrderBooks();

        UtilityResponse orderBookArrayListAction = new UtilityResponse();
        Utility utilities_filter = new Utility();


        if(orderBookArrayList != null) {
            // Filter data on order sides; Bid and Ask respectively
            Utility utilities_bid = new Utility();
            UtilityResponse orderBookArrayListBid = new UtilityResponse();
            orderBookArrayListBid = utilities_bid.filterSide(orderBookArrayList, "Bid");
            Utility utilities_ask = new Utility();
            UtilityResponse orderBookArrayListAsk = new UtilityResponse();
            orderBookArrayListAsk = utilities_ask.filterSide(orderBookArrayList, "Ask");
            HashMap<String, TreeMap<Double,HashMap<String, Object>>> topNOfTheBook = new HashMap<String, TreeMap<Double,HashMap<String, Object>>>();

            // The main processing is done in this part of the code
            // The process function are common for bid and ask orders
            if (orderBookArrayListBid.getArrayListOrderBook().isEmpty()) {
                topNOfTheBook.put("No_bids",processTopNOfBookNoData(orderBookArrayListBid));
            } else {
                TreeMap<Double, HashMap<String, Object>> nOrdersList = processTopNOfBookData(orderBookArrayListBid, "Bid", level);
                topNOfTheBook.put("Bid", nOrdersList);
            }

            if (orderBookArrayListAsk.getArrayListOrderBook().isEmpty()) {
                topNOfTheBook.put("No_asks",processTopNOfBookNoData(orderBookArrayListAsk));
            } else {
                TreeMap<Double,HashMap<String, Object>> nOrdersList = processTopNOfBookData(orderBookArrayListAsk, "Ask", level);
                topNOfTheBook.put("Ask", nOrdersList);
            }
            storeTopNOfTheBookResponse.setTopNOfTheBook(topNOfTheBook);
        } else{
            Error getAllDataError = new Error(new Date(), "No data found", "ML103");
            ArrayList<Error> listofErrors = new ArrayList<Error>();
            listofErrors.add(getAllDataError);
            storeTopNOfTheBookResponse.setErrors(listofErrors);
        }

         return storeTopNOfTheBookResponse;
    }

    /**
     * processTopNOfBookData does the main processing for getTopNOrders
     * Args: UtilityResponse Object with with Array of orders
     *       OrderSide
     * Return: A TreeMap object with price as the key; with values, total size
     * total orders
     *
     */

    private TreeMap<Double, HashMap<String, Object>> processTopNOfBookData(UtilityResponse orderBookArrayList, String orderSide, int level){
        UtilityResponse priceLotSize = new UtilityResponse();
        Utility utilities_lot_size = new Utility();
        priceLotSize = utilities_lot_size.groupByPriceLotSum(orderBookArrayList.getArrayListOrderBook());
        UtilityResponse countPriceOrders = new UtilityResponse();
        Utility utilities_cnt_ord = new Utility();
        countPriceOrders = utilities_cnt_ord.groupByPriceCountOrders(orderBookArrayList.getArrayListOrderBook());
        int numberOfOrdersBid = priceLotSize.getGroupBySum().size();
        List<Double> ind = new ArrayList<Double>(countPriceOrders.getGroupByCount().keySet());

        // Sort the orders
        if(orderSide.equals("Bid")){
            Collections.sort(ind, Collections.reverseOrder());
        }else if(orderSide.equals("Ask")){
            Collections.sort(ind);
        }
        // Return number of order depending on depth level argument
        // and availability of data
        int limitAsk = 0;
        if(numberOfOrdersBid < level){
            limitAsk = numberOfOrdersBid;
        }else{
            limitAsk = level;
        }
        // Create a TreeMap obejct to store data in sorted order
        TreeMap<Double, HashMap<String, Object>> nOrdersList = new TreeMap<Double, HashMap<String, Object>>();
        for(int i=0; i <limitAsk; i++){
            HashMap<String, Object> temp = new HashMap<String,Object>();
            temp.put("price" , ind.get(i));
            temp.put("total_orders", countPriceOrders.getGroupByCount().get(ind.get(i)));
            temp.put("total_size", priceLotSize.getGroupBySum().get(ind.get(i)));
            nOrdersList.put(ind.get(i), temp);
        }
        return nOrdersList;
    }

    private TreeMap<Double,HashMap<String, Object>> processTopNOfBookNoData(UtilityResponse orderBookArrayList){

        return (new TreeMap<Double,HashMap<String, Object>>());

    }

    /**
     * processTopOfBookData does the main processing for getTopOfTheBookOrders
     * Args: UtilityResponse Object with with Array of orders
     *       OrderSide
     * Return: A HashMap object with side as the key; with values, total size
     * total orders and best price for each side
     *
     */
    private HashMap<String, Object> processTopOfBookData(UtilityResponse orderBookArrayList, String orderSide){

        UtilityResponse priceLotSize = new UtilityResponse();
        Utility utilities_lot_size = new Utility();
        // Calling the utility functions for group by function, Sum and Counting
        priceLotSize = utilities_lot_size.groupByPriceLotSum(orderBookArrayList.getArrayListOrderBook());
        UtilityResponse countPriceOrders = new UtilityResponse();
        Utility utilities_cnt_ord = new Utility();
        countPriceOrders = utilities_cnt_ord.groupByPriceCountOrders(orderBookArrayList.getArrayListOrderBook());
        HashMap<String, Object> bestOrderDetails = new HashMap<String, Object>();
        if(orderSide.equals("Bid")) {
            // Max Bid price
            Double maxBid = Collections.max(priceLotSize.getGroupBySum().keySet());
            bestOrderDetails.put("price", maxBid);
            bestOrderDetails.put("number_of_orders", countPriceOrders.getGroupByCount()
                    .get(maxBid));
            bestOrderDetails.put("side", "Bid");
            bestOrderDetails.put("total_size", priceLotSize.getGroupBySum().get(maxBid));
        }else if (orderSide.equals("Ask")){
            // Get the min ask price
            Double minAsk = Collections.min(priceLotSize.getGroupBySum().keySet());
            HashMap<String, Object> bestOrderDetailsAsk = new  HashMap<String, Object>();
            bestOrderDetails.put("price", minAsk);
            bestOrderDetails.put("number_of_orders", countPriceOrders.getGroupByCount()
                    .get(minAsk));
            bestOrderDetails.put("side", "Ask");
            bestOrderDetails.put("total_size", priceLotSize.getGroupBySum().get(minAsk));
        }
        return bestOrderDetails;

    }

    private HashMap<String, Object> processTopOfBookNoData(UtilityResponse orderBookArrayList){

        return (new HashMap<String, Object>());

    }


}
